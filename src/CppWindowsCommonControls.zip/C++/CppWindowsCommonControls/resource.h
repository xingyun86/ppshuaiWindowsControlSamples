//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CppWindowsCommonControls.rc
//
#define IDD_MAINDIALOG                  103
#define IDD_ANIMATIONDIALOG             129
#define IDD_COMBOBOXEXDIALOG            130
#define IDD_DATETIMEPICKDIALOG          131
#define IDD_HEADERDIALOG                132
#define IDD_IPADDRESSDIALOG             133
#define IDD_LISTVIEWDIALOG              134
#define IDD_MONTHCALDIALOG              135
#define IDD_PROGRESSDIALOG              136
#define IDD_SYSLINKDIALOG               137
#define IDD_STATUSDIALOG                138
#define IDD_TABCONTROLDIALOG            139
#define IDD_TOOLBARDIALOG               140
#define IDD_TOOLTIPDIALOG               141
#define IDD_TRACKBARDIALOG              142
#define IDD_TREEVIEWDIALOG              143
#define IDD_UPDOWNDIALOG                144
#define IDR_UPLOAD_AVI                  146
#define IDI_ICON1                       147
#define IDI_ICON2                       148
#define IDI_ICON3                       149
#define IDI_ICON4                       150
#define IDI_ICON5                       151
#define IDI_ICON6                       152
#define IDI_ICON7                       153
#define IDI_ICON8                       154
#define IDI_ICON9                       155
#define IDI_ICON10                      156
#define IDD_DIALOG1                     157
#define IDD_REBARDIALOG                 157
#define IDC_BUTTON_ANIMATION            1000
#define IDC_BUTTON_COMBOBOXEX           1001
#define IDC_BUTTON_DATETIMEPICK         1002
#define IDC_BUTTON_HEADER               1003
#define IDC_BUTTON_IPADDRESS            1004
#define IDC_BUTTON_LISTVIEW             1005
#define IDC_BUTTON_MONTHCAL             1006
#define IDC_BUTTON_PROGRESS             1007
#define IDC_BUTTON_SYSLINK              1008
#define IDC_BUTTON_STATUS               1009
#define IDC_BUTTON_TABCONTROL           1010
#define IDC_BUTTON_TOOLBAR              1011
#define IDC_BUTTON_TOOLTIP              1012
#define IDC_BUTTON_TRACKBAR             1013
#define IDC_BUTTON_TREEVIEW             1014
#define IDC_BUTTON_UPDOWN               1015
#define IDC_BUTTON_REBAR                1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        158
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
